from flask import Flask, render_template, redirect, url_for, request, session, jsonify
from pymongo import MongoClient
from bson import ObjectId
from flask import send_file
from openpyxl import Workbook
from docx import Document


app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Replace with a secure secret key

# Connect to MongoDB database
client = MongoClient('mongodb://localhost:27017/')
db = client['blog']


# Define models using OOPs concepts
class User:
    def __init__(self, username, email, password):
        self.username = username
        self.email = email
        self.password = password


class Post:
    def __init__(self, title, content, author):
        self.title = title
        self.content = content
        self.author = author


@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))


@app.before_request
def before_request():
    allowed_routes = ['index', 'signup', 'dashboard', 'logout']  # Add 'dashboard' and 'logout' to allowed routes
    if 'username' not in session and request.endpoint not in allowed_routes:
        return redirect(url_for('index'))


@app.route('/', methods=['GET', 'POST'])
def index():
    if 'username' in session:  # Redirect to dashboard if user is logged in
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if user exists and password is correct
        if db.users.find_one({'username': username, 'password': password}):
            # If authentication is successful, set the user in the session
            session['username'] = username
            return redirect(url_for('dashboard'))
        else:
            error = 'Invalid username or password'
            return render_template('index.html', error=error)

    return render_template('index.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if 'username' in session:  # Redirect to dashboard if user is logged in
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        # Check if user already exists
        if db.users.find_one({'username': username}):
            error = 'Username already exists'
            return render_template('signup.html', error=error)

        # Create new user and save to database
        user = User(username, email, password)
        db.users.insert_one(user.__dict__)
        return redirect(url_for('index'))

    return render_template('signup.html')


@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        posts = db.posts.find({'author': session['username']})
        return render_template('dashboard.html', posts=posts, uname=session['username'])
    return redirect(url_for('index'))


# Update the new_post route in your Flask application
@app.route('/post/new', methods=['GET', 'POST'])
def new_post():
    if request.method == 'POST':
        if 'username' in session:
            title = request.form['title']
            content = request.form['content']
            author = session['username']

            # Create new post and save to database
            post = Post(title, content, author)
            db.posts.insert_one(post.__dict__)
            return redirect(url_for('dashboard'))
        else:
            return redirect(url_for('index'))

    return render_template('new_post.html')


@app.route('/post/<post_id>/save/excel')
def save_post_excel(post_id):
    # Retrieve post by ID
    post = db.posts.find_one({'_id': ObjectId(post_id)})

    if post:
        # Create a new Excel workbook
        wb = Workbook()
        ws = wb.active

        # Add post details to the Excel file
        ws.append(['Title', 'Content', 'Author'])
        ws.append([post['title'], post['content'], post['author']])

        # Save the Excel file
        excel_file_path = f"{post['author']}_{post['title']}.xlsx"
        wb.save(excel_file_path)

        # Return the Excel file for download
        return send_file(excel_file_path, as_attachment=True)
    else:
        return "Post not found"


@app.route('/post/<post_id>/save/word')
def save_post_word(post_id):
    # Retrieve post by ID
    post = db.posts.find_one({'_id': ObjectId(post_id)})

    if post:
        # Create a new Word document
        doc = Document()

        # Add title to the document
        doc.add_heading('Title', level=1)
        doc.add_paragraph(post['title'])

        # Add content title and content to the document
        doc.add_heading('Content', level=2)
        doc.add_paragraph(post['content'])

        # Add author and author name to the document
        doc.add_heading('Author', level=2)
        doc.add_paragraph(post['author'])

        # Save the document
        file_path = f"{post['author']}_{post['title']}.docx"
        doc.save(file_path)
        return redirect(url_for('dashboard'))
    else:
        return "Post not found"


@app.route('/post/<post_id>/delete')
def delete_post(post_id):
    # Delete post by ID
    db.posts.delete_one({'_id': ObjectId(post_id)})
    return redirect(url_for('dashboard'))


@app.route('/get_post/<postid>', methods=['GET'])
def get_post(postid):
    post = db.posts.find_one({'_id': ObjectId(postid)})
    if post:
        return jsonify({'title': post['title'], 'content': post['content']})
    else:
        return jsonify({'title': 'Post not found', 'content': 'Post not found'})


@app.route('/update_post/<post_id>', methods=['POST'])
def update_post(post_id):
    updated_title = request.form.get('title')
    updated_content = request.form.get('content')

    # Update the post in the database
    db.posts.update_one({'_id': ObjectId(post_id)}, {'$set': {'title': updated_title, 'content': updated_content}})

    return 'Post updated successfully'  # You might send a more specific response based on your needs


@app.route('/search', methods=['GET'])
def search():
    search_term = request.args.get('search_term')

    # Retrieve posts matching the search term
    posts = db.posts.find({'$or': [
        {'title': {'$regex': search_term, '$options': 'i'}},  # Case-insensitive title search
        {'content': {'$regex': search_term, '$options': 'i'}}  # Case-insensitive content search
    ]})

    return render_template('dashboard.html', posts=posts, uname=session.get('username'))


if __name__ == "__main__":
    app.run(debug=True)
